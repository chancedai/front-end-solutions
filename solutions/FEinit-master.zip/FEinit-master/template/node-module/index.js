'use strict';
//系统模块
var fs = require('fs');
var utils = require('util');
var path = require('path');

//非系统模块
var optimist = require('optimist');
var root = __dirname;
