FEinit ToDoList
=======
当前版本 v0.2.1

2013年8月24日

## v0.1.1
 * Feinit.js添加事件 √
 * 思考task实现方式，传参方法 ×
    * fe task a.js b.js c.js > concat.js
    * ...

## v0.1.3
 * 添加task帮助 √
 * 实现template创建 √
 * template使用 √
 * 设置默认template ×

## v0.1.4
 * 实现插件开发创建 √

## v0.2.0
 * 添加右键菜单集合

## task list
 * concat   √
 * css      √
 * js       √
 * build    √   
 * imgmin   √
 * tar
 * base64   √
 * live
 * watch
 * clean
 * sass
 * install